"""Improved boundary correction using local shifts, edge detection, and confidence scoring.

Modified to exclude self from nearest-neighbor shifts, enabling AUC to be computed
on the public sample (leave-one-out cross‑validation).
"""

from __future__ import annotations

import geopandas as gpd
import numpy as np
import rasterio
from scipy.spatial import cKDTree
from shapely.affinity import translate
from shapely.geometry.base import BaseGeometry
from rasterio.windows import from_bounds

from bhume.geo import geom_to_imagery_crs, patch_for_plot, open_imagery


def _utm_for(geom: BaseGeometry) -> str:
    lon = geom.centroid.x
    return f'EPSG:{32600 + int((lon + 180) // 6) + 1}'


def _edge_strength_in_patch(image_rgb: np.ndarray) -> float:
    """Estimate edge density in an image patch using gradient magnitude."""
    if image_rgb.size == 0 or image_rgb.shape[0] < 3 or image_rgb.shape[1] < 3:
        return 0.0
    
    # Convert to grayscale
    gray = np.mean(image_rgb.astype(float), axis=2)
    
    # Sobel-like edge detection: compute gradients
    gy, gx = np.gradient(gray)
    magnitude = np.sqrt(gx**2 + gy**2)
    
    # Threshold and count
    threshold = np.percentile(magnitude, 50)
    edge_pixels = np.sum(magnitude > threshold)
    return float(edge_pixels / magnitude.size)


def _boundary_raster_strength(boundaries_path: str | None, geom_4326: BaseGeometry) -> float:
    """Score how much boundary hint exists in the optional boundaries.tif."""
    if boundaries_path is None:
        return 0.0
    try:
        with rasterio.open(boundaries_path) as src:
            patch = patch_for_plot(src, geom_4326, pad_m=20)
            if patch.image.size == 0:
                return 0.0
            # boundaries.tif is single-channel; treat non-zero as boundary
            boundary_pixels = np.count_nonzero(patch.image)
            return float(boundary_pixels / patch.image.size)
    except Exception:
        return 0.0


def _compute_confidence(
    distance_to_truth_m: float,
    edge_strength: float,
    boundary_strength: float,
    plot_area_sqm: float,
    shift_variance: float = 0.0,
) -> float:
    """Compute confidence based on shift consistency + image clarity.
    
    High confidence when:
    - Nearby plots have similar shifts (consensus)
    - Clear edges in imagery
    - Larger plots
    """
    # Shift consistency: low variance = high confidence (all neighbors agree on shift)
    # shift_variance will be 0-1 where 0 = all neighbors agree, 1 = disagreement
    consistency_score = 1.0 - min(shift_variance, 1.0)
    
    # Edge clarity: plots with clear edges are more confident
    edge_score = edge_strength
    
    # Boundary hints: if available, boost confidence
    boundary_score = boundary_strength
    
    # Plot area: larger plots easier to correct
    area_score = min(plot_area_sqm / 2000.0, 1.0)
    
    # Blend: 40% consistency + 40% edge + 10% boundary + 10% area
    # High weighting on agreement (consensus) and edge clarity
    confidence = (
        0.40 * consistency_score +
        0.40 * edge_score +
        0.10 * boundary_score +
        0.10 * area_score
    )
    
    return float(np.clip(confidence, 0.25, 0.90))


def local_shift_with_edge_confidence(village) -> gpd.GeoDataFrame:
    """Correct plots using local nearest-truth shifts + edge-based confidence.
    
    This method:
    1. Finds the median shift from nearby example-truth plots (k=5 nearest),
       EXCLUDING the plot itself if it is one of the example truths (leave‑one‑out).
    2. Applies that local shift to each plot
    3. Scores confidence based on:
       - Proximity to example-truth plots
       - Edge clarity in the satellite imagery
       - Boundary hints from boundaries.tif (if available)
       - Plot area (larger plots easier to correct)
    4. Flags plots with low confidence (keeps official geometry, status='flagged')
    """
    if village.example_truths is None:
        raise ValueError(f'{village.slug} has no example_truths.geojson')
    
    utm = _utm_for(village.example_truths.geometry.iloc[0])
    official_u = village.plots.to_crs(utm)
    truth_u = village.example_truths.to_crs(utm)
    
    # Step 1: Compute shift vectors from example truths
    shifts = []
    tree_points = []
    shift_by_idx = {}  # map plot_number -> (dx, dy)
    for pn in village.example_truths.index:
        if pn not in official_u.index:
            continue
        official_c = official_u.loc[pn, 'geometry'].centroid
        truth_c = truth_u.loc[pn, 'geometry'].centroid
        dx, dy = truth_c.x - official_c.x, truth_c.y - official_c.y
        shifts.append((dx, dy))
        tree_points.append((official_c.x, official_c.y))
        shift_by_idx[pn] = (dx, dy)
    
    if not shifts:
        raise ValueError('no overlapping example truths in the cadastre')
    
    tree = cKDTree(tree_points)
    
    # Step 2: Open imagery once for all patches
    imagery_src = open_imagery(village.imagery_path)
    
    results = []
    for idx, (pn, row) in enumerate(village.plots.iterrows()):
        official_geom_u = official_u.loc[pn, 'geometry']
        plot_area_sqm = float(row.get('map_area_sqm', 1000))
        
        # Find k nearest truth plots, EXCLUDING this plot if it is one of the truths
        centroid = official_geom_u.centroid
        # Get distances to all truth points
        all_distances, all_indices = tree.query((centroid.x, centroid.y), k=len(shifts))
        
        # Filter out the current plot if it exists among truth points
        filtered_distances = []
        filtered_indices = []
        for dist, idx_truth in zip(all_distances, all_indices):
            truth_pn = village.example_truths.index[idx_truth]
            if truth_pn != pn:   # exclude self
                filtered_distances.append(dist)
                filtered_indices.append(idx_truth)
            if len(filtered_indices) >= 5:   # we only need 5 nearest
                break
        
        if not filtered_indices:
            # Fallback: use global median shift
            global_dx = np.median([s[0] for s in shifts])
            global_dy = np.median([s[1] for s in shifts])
            dx, dy = global_dx, global_dy
            nearest_distance = 1000.0   # far away
        else:
            selected_shifts = np.array([shifts[i] for i in filtered_indices[:5]])
            nearest_distance = float(filtered_distances[0])
            dx = float(np.median(selected_shifts[:, 0]))
            dy = float(np.median(selected_shifts[:, 1]))
        
        # Apply shift in UTM, convert back to 4326
        corrected_u = translate(official_geom_u, dx, dy)
        corrected_4326 = gpd.GeoSeries([corrected_u], crs=utm).to_crs('EPSG:4326').iloc[0]
        
        # Compute edge strength in the imagery
        try:
            patch = patch_for_plot(imagery_src, row.geometry, pad_m=25)
            edge_strength = _edge_strength_in_patch(patch.image)
        except Exception:
            edge_strength = 0.0
        
        # Boundary raster strength
        boundary_strength = _boundary_raster_strength(
            str(village.boundaries_path) if village.boundaries_path else None,
            row.geometry
        )
        
        # Compute confidence (variance not used yet, set to 0)
        confidence = _compute_confidence(
            nearest_distance,
            edge_strength,
            boundary_strength,
            plot_area_sqm,
            shift_variance=0.0
        )
        
        # Ensure confidence is standard Python float
        confidence = float(confidence)
        
        # Decision: flag low-confidence plots (keep original), correct high-confidence
        if confidence < 0.50:
            status = 'flagged'
            geometry = row.geometry  # Keep original
        else:
            status = 'corrected'
            geometry = corrected_4326  # Use shifted
        
        results.append({
            'plot_number': str(pn),
            'geometry': geometry,
            'status': status,
            'confidence': confidence if status == 'corrected' else None,
            'method_note': (
                f'{status}: shift dx={dx:.1f}m dy={dy:.1f}m conf={confidence:.2f} '
                f'(edge={edge_strength:.2f} boundary={boundary_strength:.2f})'
            ),
        })
    
    imagery_src.close()
    
    # Step 3: Build output GeoDataFrame
    result_df = gpd.GeoDataFrame(results, geometry='geometry', crs='EPSG:4326')
    result_df = result_df.set_index('plot_number', drop=False)
    
    # Keep only required columns for write_predictions
    return result_df[['plot_number', 'status', 'confidence', 'method_note', 'geometry']]