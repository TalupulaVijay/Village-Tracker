#!/usr/bin/env python3
"""
Worked end-to-end example — load → look → predict → score.

This is the whole loop in ~15 lines of real work. It drops you exactly where the interesting
part starts: you have the image under a plot, a naive prediction, and a score. Everything after
this — a better correction, a confidence that means something — is yours.

Run (after downloading a bundle into data/<village>/):
    uv run quickstart.py data/34855_vadnerbhairav_chandavad_nashik
"""

from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image

from bhume import load, patch_for_plot, score, write_predictions
from bhume.baseline import global_median_shift
from bhume.geo import open_imagery
from bhume.improved import local_shift_with_edge_confidence

DEFAULT_VILLAGE = 'data/Vadnerbhairav'


def main(village_dir: str) -> None:
    village = load(village_dir)
    n_truth = 0 if village.example_truths is None else len(village.example_truths)
    print(f'Loaded {village.slug}')
    print(f'  {len(village.plots)} plots · {n_truth} example truths · '
          f'boundaries={"yes" if village.boundaries_path else "none"}')

    # 1) Look at the imagery under one plot — this is your substrate.
    pn = village.plots.index[0]
    with open_imagery(village.imagery_path) as src:
        patch = patch_for_plot(src, village.plot(pn), pad_m=30)
    Image.fromarray(patch.image).save('patch_example.png')
    print(f'  image patch under plot {pn}: {patch.image.shape} → saved patch_example.png')

    print('\n' + '='*70)
    print('BASELINE: Global Median Shift')
    print('='*70)
    # 2a) Baseline prediction (the floor to beat).
    baseline_preds = global_median_shift(village)
    baseline_out = write_predictions(Path(village_dir) / 'predictions.geojson', baseline_preds)
    print(f'wrote {len(baseline_preds)} predictions → {baseline_out}')
    baseline_score = score(baseline_preds, village)
    print(baseline_score)

    print('\n' + '='*70)
    print('IMPROVED: Local Shift + Edge-Based Confidence')
    print('='*70)
    # 2b) Improved prediction (using local shifts + edge detection + confidence).
    improved_preds = local_shift_with_edge_confidence(village)
    improved_out = write_predictions(Path(village_dir) / 'predictions.geojson', improved_preds)
    print(f'wrote {len(improved_preds)} predictions → {improved_out}')
    improved_score = score(improved_preds, village)
    print(improved_score)

    # 3) Compare
    print('\n' + '='*70)
    print('COMPARISON')
    print('='*70)
    if improved_score.median_iou_pred is not None and baseline_score.median_iou_pred is not None:
        iou_delta = improved_score.median_iou_pred - baseline_score.median_iou_pred
        print(f'Median IoU improvement: {iou_delta:+.3f}')
    if improved_score.accurate_rate is not None and baseline_score.accurate_rate is not None:
        acc_delta = improved_score.accurate_rate - baseline_score.accurate_rate
        print(f'Accuracy rate change: {acc_delta:+.3f}')
    print(f'\n✓ Final predictions written to: {improved_out}')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VILLAGE)
